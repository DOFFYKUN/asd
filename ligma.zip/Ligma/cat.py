from selenium import webdriver
import time
import sys
import random

from random import randint
import time
import json


class tools():
    def __init__(self, low=None, high=None):
        try:
            self.low = low
            self.high = high
        except:
            pass

    def oneDay(self, tstamp):
        "Checks if time stamp has had 86400 seconds(one day) elapsed"
        if not tstamp:
            return True
        tstamp = int(tstamp)
        if (time.time() - tstamp) > 86400:
            return True
        return False

    def fetchStack(self):
        return [json.loads(x.strip()) for x in open("data.json", "r").readlines()]

    def skeltons(self):
        """
        Updates data.json from accounts.txt
        Creates json skelton if username from accounts.txt not found

        flow:
        Checks for data.json if not found create new
        opens username:passwords from accounts.txt
        if username not in data.json create entry skeleton
        :return:
        """
        try:
            open("data.json")
        except:
            filey = open("data.json", "w")
            filey.close()
        county = 0

        with open("accounts.txt", "r") as f:
            creds = [x.strip() for x in f.readlines()]

        data = [json.loads(x.strip()) for x in open("data.json", "r").readlines()]
        curAcks = [list(key.keys()).pop() for key in data]

        for cred in creds:
            if not curAcks.__contains__(cred.split(":")[0]):
                curAcks.append(cred.split(":")[0])
                username, password = cred.split(":")[0], cred.split(":")[1]
                print(("Username => ", username, " Added to stack"))
                dict = {username: {"password": password,
                                   "banned": False,
                                   "LastScrape": False,
                                   "totalFollows": 0,
                                   "todayFollows": 0,
                                   "goal": False}
                        }

                with open("data.json", 'a') as f:
                    json.dump(dict, f)
                    f.write("\n")
                    f.flush()
                county += 1
        print(("Total accounts added to stack => ", county))
        print(("Total Stack => ", len(curAcks)))

    def rng(self, low, high):
        "Returns a random int from range lowest to highest variable"
        return randint(low, high)

    def update(self, username, banned=None, totalFollows=None, todayFollows=None, lastScrape=None, goal=None):
        """Updates the data.json file"""
        stack = self.fetchStack()
        for creds in stack:
            user = list(creds.keys()).pop()
            if user == username:
                if banned:
                    print(("User banned => ", username))
                    creds[username]["banned"] = True

                if totalFollows:
                    creds[username]["totalFollows"] = totalFollows

                if todayFollows is not None:
                    creds[username]["todayFollows"] = todayFollows

                if lastScrape:
                    creds[username]["LastScrape"] = lastScrape

                if goal:
                    creds[username]['goal'] = goal

        with open("data.json", 'w') as f:
            for x in stack:
                json.dump(x, f)
                f.write("\n")
                f.flush()

    def checkGoals(self, block, username):
        goal = block[username]['goal']
        if not goal:
            goal = self.rng(self.low, self.high)
            print(("Creating new goal =>", username, "Goal => ", goal))
            self.update(username, goal=goal)
            return True
        followedToday = block[username]['totalFollows']
        if goal >= followedToday:
            print(("Username:", username, " [Goal ", goal, " | ", "followed", followedToday))
            return True
        return False

    def rinse(self, block, username):
        """
        Checks to see if username is ready for scrape
        if Username not banned and new/first day and goal either new or not achieved:
            return True


        Flow:
        Check if user banned
        Check if first/newDay
        If first/newday then:
            if dailyGoal > TodayFollows or goal False:

            else:
                set new daily goal


        :param block:
        :param username:
        :return:
        """
        if block[username]['banned']:
            print(("User banned => ", username))
            return False

        tstamp = block[username]["LastScrape"]
        ret = self.oneDay(tstamp)
        if ret:
            bool = self.checkGoals(block, username)
            if bool:
                return True
        return False


class bot():
    def __init__(self):
        # self.tools = tools(0,0)
        self.SCROLLSCRIPT = '$(".scroller.is-scrollable.scroll-content.scroll-scrolly_visible").last().addClass("FLICK");$(".FLICK").scrollTop($(".FLICK")[0].scrollHeight);'

    def finPool(self):
        targets = [x.strip() for x in open("pool.txt").readlines()]
        random.shuffle(targets)
        stack = []
        for x in range(0, 5):
            try:
                stack.append(x)
            except:
                pass
        return stack

    def pool(self, targets):
        """Saves target usernames for use on other accounts if later needed"""
        try:
            data = [x.strip() for x in open("pool.txt").readlines()]
        except:
            open('pool.txt', "w").close()
            data = []
        for target in targets:
            if target not in data:
                with open("pool.txt", 'a') as f:
                    f.write(target + "\n")
                    print(("Wrote user => ", target, " to pool "))
                data.append(target)

    def getBurnt(self):
        return [x.strip() for x in open("burnt.txt").readlines()]

    def writeBurnt(self, user):
        with open("burnt.txt", 'a') as f:
            f.write(user + "\n")
            f.flush()

    def login(self, username, password):
        self.destroyDriver()
        try:

            print(("Logging into => ", username))
            chrome_options = webdriver.ChromeOptions()
            # chrome_options.add_argument('--proxy-server=%s' % PROXY)
            chrome_options.add_argument('--window-size=1420,1080')
            # chrome_options.add_argument('--headless')
            self.driver = webdriver.Chrome()
            self.driver.implicitly_wait(10)
            self.driver.get("https://pl.secure.imvu.com/welcome/login/")
            self.driver.find_element_by_name("avatarname").send_keys(username)
            self.driver.find_element_by_name("password").send_keys(password)
            self.driver.find_element_by_class_name("btn-primary").click()
            time.sleep(8.5)
            if "welcome/login" in self.driver.current_url:
                self.destroyDriver()
                return False
        except:
            self.destroyDriver()
            return 17
        return True

    def fetchTargets(self, scroll=None):
        time.sleep(5)
        self.driver.get("https://pl.secure.imvu.com/next/feed/explore/")
        time.sleep(5)
        segmented_control_buttons = self.driver.find_elements_by_class_name("segmented-control-item")
        segmented_control_buttons[1].click()
        time.sleep(6)
        if scroll:
            for x in range(0, scroll):
                print(("Rescrolling username=>", self.username))
                time.sleep(3)
                self.driver.execute_script(self.SCROLLSCRIPT)
            time.sleep(3)
        posts = self.driver.find_elements_by_css_selector("article.feed-item")
        print((str(len(posts)) + " posts found."))
        targets = []
        for post in posts:
            time.sleep(1)
            targets.append(post.find_element_by_class_name("new-profile-icon").get_attribute("title"))
            print(("Total targets found => ", len(targets)))
        return targets

    def follow(self, target):
        print(("Navigating to " + target + " user."))
        self.driver.get("https://pl.secure.imvu.com/next/av/" + target)
        time.sleep(5)
        try:
            self.driver.find_element_by_css_selector("[data-btn='followers']").click()
        except:
            return False
        time.sleep(6)
        for scroll in range(0, 15):
            try:
                self.driver.execute_script(self.SCROLLSCRIPT)
            except:
                pass
            print(("Scroll ", scroll))
            time.sleep(3)

        followers = self.driver.find_elements_by_class_name("profile-list-item")
        print(("Loaded ", len(followers), " followers"))
        for cell in followers:
            try:
                tname = cell.find_element_by_class_name("at-avatar-name-text").text.strip()
                burnt = self.getBurnt()
                if tname not in burnt:
                    btn = cell.find_element_by_class_name("follow-button")
                    if btn.text == "FOLLOW":
                        self.driver.execute_script("return arguments[0].scrollIntoView(true);", btn)
                        self.driver.execute_script("window.scrollBy(0, 20);")
                        btn.click()
                        time.sleep(0.5)
                        self.todayFollows += 1
                        self.totalFollows += 1
                        print((self.username, " | Followed => ", tname, " | ", "Fcount => ", self.todayFollows,
                               " | Todays goal => ", self.goal))
                        self.writeBurnt(tname)
                        self.tools.update(self.username, todayFollows=self.todayFollows, totalFollows=self.totalFollows)
            except:
                print("Couldn't follow")
            if self.todayFollows >= self.goal:
                print(("Self.todayFollows", self.todayFollows))
                print(("self.goal", self.goal))
                self.destroyDriver()
                print(("[+] Finished [+]", " | Goal => ", self.goal, " todayFollowed => ", self.todayFollows))
                return True
        return False

    def destroyDriver(self):
        try:
            self.driver.quit()
        except:
            pass

    def starty(self, block, username):
        self.username = username
        self.password = block[username]['password']
        self.goal = block[username]['goal']
        self.todayFollows = block[username]['todayFollows']
        self.totalFollows = block[username]['totalFollows']

        targets = self.fetchTargets()
        self.pool(targets)
        for target in targets:
            ret = self.follow(target)
            if ret:
                return True

        # print ("Fetching extra")
        # targets = self.fetchTargets(scroll=10)
        # self.pool(targets)
        # for target in targets:
        #    ret = self.follow(target)
        #    if ret:
        #        return True

        # print ("Fetching from pool")
        # targets = self.finPool()
        # for target in targets:
        #    ret = self.follow(target)
        #    if ret:
        #       return True

        self.destroyDriver()
        return False


low = 990
high = 1000

tools = tools(low, high)
tools.skeltons()
stack = tools.fetchStack()

PROXY = ""

bot = bot()

while True:
    ready = []
    for block in stack:
        for username in block:
            ret = tools.rinse(block, username)
            if ret:
                ready.append(username)

    stack = tools.fetchStack()
    for block in stack:
        for username in block:
            for x in ready:
                if username == x:
                    rdy = bot.login(username, block[username]['password'])
                    if not rdy:
                        tools.update(username, banned=True)
                    elif rdy != 17:
                        met = bot.starty(block, username)
                        if met:
                            tools.update(username, todayFollows=0, lastScrape=time.time())
                sys.stdout.flush()
    time.sleep(60 * 5)